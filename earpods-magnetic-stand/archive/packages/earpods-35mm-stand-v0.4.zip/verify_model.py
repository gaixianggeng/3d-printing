"""复核本目录导出的 STL；只验证数字几何，不代替实物试装。"""
from pathlib import Path
import hashlib
import json
import re

import manifold3d as md
import numpy as np
import trimesh

ROOT = Path(__file__).resolve().parent
SOURCE = (ROOT / "earpods_stand.scad").read_text()


def param(name):
    return float(re.search(rf"^{name}\s*=\s*([\d.]+);", SOURCE, re.M)[1])


def solid(mesh):
    result = md.Manifold(md.Mesh(
        np.asarray(mesh.vertices, dtype=np.float32),
        np.asarray(mesh.faces, dtype=np.uint32),
    ))
    assert result.status() == md.Error.NoError, result.status()
    return result


def moved(mesh, xyz, angle=0):
    result = mesh.copy()
    result.apply_transform(trimesh.transformations.rotation_matrix(angle, [1, 0, 0]))
    result.apply_translation(xyz)
    return result


def box(size, center):
    return moved(trimesh.creation.box(extents=size), center)


def cylinder(radius, height, center, angle=0):
    return moved(trimesh.creation.cylinder(radius=radius, height=height, sections=128), center, angle)


parts = {name: trimesh.load_mesh(ROOT / "exports" / f"{name}.stl")
         for name in ("body", "lid", "stand", "fit_coupon", "ear_fit_coupon")}
report = {
    "version": "0.4",
    "units": "mm",
    "source_sha256": hashlib.sha256(SOURCE.encode()).hexdigest(),
    "parts": {},
    "checks": [],
    "limits": [
        "耳机参考为第三方尺寸图的最大外形包络，不是实物扫描。",
        "只检查两种正交朝向和背面直线放入，不证明任意旋转下的夹持。",
        "线控包络和双线直径为设计检查值，不是实测 EarPods 数据。",
        "试装件仅检查平面卡位和放入路径，不能验证整机合盖深度。",
        "未验证实物、公差收缩、完整绕线、磁吸力度、切片、打印和拾音效果。",
    ],
}
for name, mesh in parts.items():
    assert mesh.is_watertight and mesh.is_winding_consistent, name
    assert len(mesh.split()) == 1, name
    solid(mesh)
    report["parts"][name] = {
        "watertight": True, "connected_components": 1,
        "bounds_mm": np.round(mesh.bounds, 4).tolist(),
        "extents_mm": np.round(mesh.extents, 4).tolist(),
        "volume_mm3": round(mesh.volume, 3),
        "sha256": hashlib.sha256((ROOT / "exports" / f"{name}.stl").read_bytes()).hexdigest(),
    }


def check(name, a, b, blocked=False):
    overlap = md.Manifold.batch_boolean([solid(a), solid(b)], md.OpType.Intersect)
    assert overlap.status() == md.Error.NoError, (name, overlap.status())
    volume = abs(overlap.volume())
    passed = np.isfinite(volume) and (volume > 1 if blocked else volume < 0.001)
    report["checks"].append({"name": name, "expected": "blocked" if blocked else "clear",
                            "intersection_mm3": round(volume, 6), "passed": bool(passed)})
    assert passed, report["checks"][-1]


front = param("front_t")
depth = param("body_depth")
lid_t = param("lid_t")
ear_x = param("ear_x")
body = parts["body"]
lid = moved(parts["lid"], [0, 0, depth + lid_t], np.pi)
check("body_lid", body, lid)
reference = trimesh.load_mesh(ROOT / "preview" / "envelopes.stl")
check("body_reference_envelopes", body, reference)
check("lid_reference_envelopes", lid, reference)

ear_reference = json.loads(re.search(r"ear_reference\s*=\s*(\[[^;]+\]);", SOURCE)[1])
ear_w, ear_l, ear_d = ear_reference
for x in (-ear_x, ear_x):
    for orientation, (width, thickness) in enumerate(((ear_w, ear_d), (ear_d, ear_w))):
        # 完整矩形包络比真实曲面保守，尤其能发现槽内圆角的干涉。
        ear = box([width, ear_l, thickness], [x, 0, front + 0.8 + thickness / 2])
        check(f"ear_{x}_{orientation}_body", body, ear)
        check(f"ear_{x}_{orientation}_lid", lid, ear)
        # 垂直拉长的包络覆盖从背面放入到落座的整段直线路径。
        sweep = box([width, ear_l, 50], [x, 0, front + 0.8 + 25])
        check(f"ear_{x}_{orientation}_insertion", body, sweep)
        coupon_ear = moved(ear, [-x, 0, 0])
        check(f"ear_coupon_{x}_{orientation}", parts["ear_fit_coupon"], coupon_ear)
    # 此位置已越过槽壁；验证新增后盖限位台确实阻挡该抬起位置。
    lifted = box([ear_d, ear_l, ear_w], [x, 0, front + 10 + ear_w / 2])
    check(f"ear_{x}_raised_escape_position", lid, lifted, blocked=True)

# 6 × 30 × 5 仅是狭窄线控的合成测试块，不能当作 EarPods 线控尺寸。
falling_remote = box([6, 30, 5], [0, 0, front - 1 + 2.5])
check("front_bars_support_synthetic_narrow_remote", body, falling_remote, blocked=True)

magnet_d, magnet_h = param("magnet_d"), param("magnet_h")
inner_r = param("head_d") / 2 - param("wall_t")
boss_r = (magnet_d + param("magnet_d_clearance")) / 2 + 2.5
magnet_y = inner_r - boss_r + 1.1
for name, mesh, surface in (("body", body, depth), ("lid", parts["lid"], lid_t)):
    for y in (-magnet_y, magnet_y):
        magnet = cylinder(magnet_d / 2, magnet_h, [0, y, surface - magnet_h / 2])
        check(f"{name}_magnet_{y:.2f}", mesh, magnet)

for x in (param("outlet_x") - 1.1, param("outlet_x") + 1.1):
    wire = cylinder(1, 13, [x, -55.5, depth - param("outlet_w") / 2], np.pi / 2)
    check(f"body_wire_{x}", body, wire)
    check(f"lid_wire_{x}", lid, wire)

head_position = [0, (depth + lid_t) / 2, param("stem_top") + param("head_d") / 2]
check("body_stand", moved(body, head_position, np.pi / 2), parts["stand"])
check("lid_stand", moved(lid, head_position, np.pi / 2), parts["stand"])
# 从 OpenSCAD 实际装配变换导出的圆盘检查中线，避免只检查手写坐标公式。
head_mesh = trimesh.load_mesh(ROOT / "preview" / "head_alignment.stl")
head_center_xy = head_mesh.bounds.mean(axis=0)[:2]
base_center_xy = parts["stand"].bounds.mean(axis=0)[:2]
offset = head_center_xy - base_center_xy
assert np.max(np.abs(offset)) < 0.001, offset
report["alignment"] = {"head_to_base_center_offset_xy_mm": offset.tolist(), "passed": True}
# 插舌最低 1 mm 横截面的中心应落在支杆插孔中心。
toe = md.Manifold.batch_boolean([solid(body), solid(box([200, 1, 100], [0, -param("head_d")/2-param("tenon_l")+0.5, 0]))], md.OpType.Intersect)
assert toe.status() == md.Error.NoError and toe.volume() > 1
toe_bounds = np.asarray(toe.bounding_box()).reshape(2, 3)
assert abs(toe_bounds.mean(axis=0)[2] - head_position[1]) < 0.001
report["ear_clearances_mm"] = {
    "nominal_width_per_side": (param("ear_space_w") - ear_w) / 2,
    "rotated_width_per_side": (param("ear_space_w") - ear_d) / 2,
    "length_per_end": (param("ear_space_l") - ear_l) / 2,
    "closed_depth": param("ear_closed_depth"),
    "rear_gap_after_0.8_pad_nominal": param("ear_closed_depth") - ear_d - 0.8,
    "rear_gap_after_0.8_pad_rotated": param("ear_closed_depth") - ear_w - 0.8,
    "actual_wall_height_above_front_floor": param("holder_h") - 0.02,
}
report["passed"] = True
(ROOT / "preview" / "geometry-check.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"parts": len(parts), "checks": len(report["checks"]), "passed": True,
                  "clearances": report["ear_clearances_mm"]}, ensure_ascii=False, indent=2))
