// EarPods 圆盘收纳支架，单位：mm。
// 状态：结构初稿。耳机接口、实物尺寸、分线长度和电脑侧外露长度尚未确认。
// 只收纳出线口至两耳的上段；电脑连接主线外露，不把整条耳机线绕入外壳。
// 外壳容纳尺寸为待实物验证的设计包络，不是 Apple 官方工程尺寸。
// 所有单件已按建议打印方向放置；预览中的耳机和磁铁不能打印。

/* [Export] */
part = "assembly"; // [assembly,open,exploded,body,lid,stand,fit_coupon,layout,envelopes,collision]
show_contents = true;

/* [Magnets] */
magnet_d = 5;
magnet_h = 3;
magnet_d_clearance = 0.30; // 直径总余量，并非每侧余量
magnet_depth_clearance = 0.15;

/* [Housing] */
head_d = 116;
front_t = 2.4;
wall_t = 2.4;
body_depth = 27.6;
lid_t = 4.6;
lip_h = 1.8;
lip_t = 1.6;
lip_clearance = 0.30; // 径向单侧间隙

/* [EarPods - measure before final print] */
ear_space_w = 24;
ear_space_l = 44;
ear_x = 23;
holder_t = 1.6;
holder_h = 9;
remote_space_w = 13;
remote_space_l = 56;
remote_window_w = 8;
remote_window_l = 48;
remote_backstop_h = 16;

/* [Stand] */
base_d = 108;
base_h = 8;
stem_d = 20;
stem_top = 60;
tenon_w = 8;
tenon_depth = 12;
tenon_l = 8;
joint_clearance = 0.40; // 接口总间隙

/* [Hidden] */
$fn = 128;
eps = 0.02;
R = head_d / 2;
inner_r = R - wall_t;
magnet_hole_d = magnet_d + magnet_d_clearance;
magnet_hole_h = magnet_h + magnet_depth_clearance;
boss_r = magnet_hole_d/2 + 2.5;
magnet_y = inner_r - boss_r + 1.1;
spool_r = 41.5;
spool_t = 1.6;
shell_color = [0.84, 0.83, 0.78];
lid_color = [0.91, 0.90, 0.86];
head_center_h = stem_top + R;

assert(lid_t - magnet_hole_h >= 1.2, "磁铁孔底至少保留 1.2 mm 材料");
assert(body_depth - front_t >= 23, "当前 EarPods 包络至少需要 23 mm 内深");
assert(magnet_d <= 5, "增大磁铁后需重新核对绕线通道");

module rounded_rect(w,l,r=2) {
    hull() for(x=[-w/2+r,w/2-r],y=[-l/2+r,l/2-r])
        translate([x,y]) circle(r=r,$fn=48);
}

module beveled_disk(d,h,c=0.6) {
    union() {
        cylinder(d1=d-2*c,d2=d,h=c);
        translate([0,0,c]) cylinder(d=d,h=h-2*c);
        translate([0,0,h-c]) cylinder(d1=d,d2=d-2*c,h=c);
    }
}

module magnet_positions() {
    for(y=[-magnet_y,magnet_y]) translate([0,y,0]) children();
}

module pocket_ring(w,l) {
    difference() {
        linear_extrude(holder_h) difference() {
            rounded_rect(w+2*holder_t,l+2*holder_t,3+holder_t);
            rounded_rect(w,l,3);
        }
        // 上下开口允许从背面放线，无须让 USB-C 或 Lightning 插头穿小孔。
        for(y=[-l/2,l/2]) translate([-3.5,y-3,-eps]) cube([7,6,holder_h+2*eps]);
    }
}

module remote_ring() {
    difference() {
        linear_extrude(holder_h) difference() {
            rounded_rect(remote_space_w+2*holder_t,remote_space_l+2*holder_t,3.5);
            rounded_rect(remote_space_w,remote_space_l,2);
        }
        for(y=[-remote_space_l/2,remote_space_l/2])
            translate([-2.2,y-3,-eps]) cube([4.4,6,holder_h+2*eps]);
    }
}

module front_holes() {
    for(s=[-1,1],x=[-7.5,-2.5,2.5,7.5],y=[-15:5:15])
        translate([s*ear_x+x,y,-eps]) cylinder(d=2.2,h=front_t+2*eps,$fn=32);
    translate([0,0,-eps]) linear_extrude(front_t+2*eps)
        rounded_rect(remote_window_w,remote_window_l,remote_window_w/2);
}

module cable_exit() {
    // 槽从后缘敞开，装入整条线后再合盖；保留底部磁铁座。
    translate([12,-R-3,body_depth-2.1]) rotate([-90,0,0])
        cylinder(d=4.2,h=10,$fn=40);
    translate([9.9,-R-3,body_depth-2.1]) cube([4.2,10,8]);
}

module body() {
    difference() {
        union() {
            difference() {
                // 背面接缝保留平直密合边，仅对前脸外沿倒角。
                union() {
                    cylinder(d1=head_d-1.2,d2=head_d,h=0.6);
                    translate([0,0,0.6]) cylinder(d=head_d,h=body_depth-0.6);
                }
                translate([0,0,front_t]) cylinder(r=inner_r,h=body_depth);
            }
            // 接头与前脸共面，外壳平放即可打印，不悬空生成插舌。
            translate([-tenon_w/2,-R-tenon_l,0]) cube([tenon_w,tenon_l+3,tenon_depth]);
            // 平肩承担竖向载荷，避免圆弧底部仅以一条线接触支杆。
            translate([-7,-R,0]) cube([14,3,tenon_depth]);
            translate([0,0,front_t-eps]) {
                for(x=[-ear_x,ear_x]) translate([x,0,0]) pocket_ring(ear_space_w,ear_space_l);
                remote_ring();
                difference() {
                    cylinder(r=spool_r+spool_t/2,h=8);
                    translate([0,0,-eps]) cylinder(r=spool_r-spool_t/2,h=8+2*eps);
                    for(y=[-spool_r,spool_r]) translate([-5,y-3,-eps]) cube([10,6,8+2*eps]);
                }
            }
            // 磁铁座与外壁重叠连接，避免独立悬浮柱。
            magnet_positions() translate([0,0,front_t-eps]) cylinder(r=boss_r,h=body_depth-front_t+eps);
        }
        front_holes();
        magnet_positions() translate([0,0,body_depth-magnet_hole_h])
            cylinder(d=magnet_hole_d,h=magnet_hole_h+eps,$fn=64);
        cable_exit();
        // 右侧后缘指甲缺口，用于揭开磁吸盖。
        translate([R-1.7,0,body_depth-0.8]) scale([1,1,0.55]) sphere(r=5,$fn=48);
    }
}

module lid() {
    difference() {
        union() {
            // 外表面向下打印，磁铁孔、定位边和限位筋均朝上。
            cylinder(d1=head_d-1.2,d2=head_d,h=0.6);
            translate([0,0,0.6]) cylinder(d=head_d,h=lid_t-0.6);
            translate([0,0,lid_t-eps]) difference() {
                cylinder(r=inner_r-lip_clearance,h=lip_h+eps);
                translate([0,0,-eps]) cylinder(r=inner_r-lip_clearance-lip_t,h=lip_h+3*eps);
                magnet_positions() translate([0,0,-eps]) cylinder(r=boss_r+lip_clearance+0.4,h=lip_h+3*eps);
                // 装配时盖子绕 X 轴翻转，因此线槽在盖子的正 Y 侧。
                translate([8.5,R-10,-eps]) cube([7,15,lip_h+3*eps]);
            }
            // 只限制线控向后跳出，不接触按钮；允许放置可移除的软垫。
            for(x=[-4.4,4.4]) translate([x-0.9,-21,lid_t-eps])
                cube([1.8,42,remote_backstop_h+eps]);
        }
        magnet_positions() translate([0,0,lid_t-magnet_hole_h])
            cylinder(d=magnet_hole_d,h=magnet_hole_h+eps,$fn=64);
    }
}

module stand() {
    difference() {
        union() {
            beveled_disk(base_d,base_h,0.7);
            translate([0,0,base_h-eps]) cylinder(d1=28,d2=stem_d,h=5);
            translate([0,0,base_h+4.9]) cylinder(d=stem_d,h=stem_top-base_h-4.9);
        }
        translate([-(tenon_w+joint_clearance)/2,-(tenon_depth+joint_clearance)/2,stem_top-tenon_l-0.4])
            cube([tenon_w+joint_clearance,tenon_depth+joint_clearance,tenon_l+0.5]);
        // 插孔入口倒角减少首装阻力；主体保持较长配合面。
        hull() {
            translate([0,0,stem_top-0.8]) cube([tenon_w+joint_clearance,tenon_depth+joint_clearance,0.02],center=true);
            translate([0,0,stem_top+0.01]) cube([tenon_w+joint_clearance+0.8,tenon_depth+joint_clearance+0.8,0.02],center=true);
        }
    }
}

module fit_coupon() {
    difference() {
        linear_extrude(4.6) rounded_rect(57,18,3);
        for(i=[0:2]) {
            translate([-18+i*18,0,4.6-magnet_hole_h]) cylinder(d=magnet_d+[0.15,0.30,0.45][i],h=magnet_hole_h+eps,$fn=64);
            translate([-18+i*18,-6.5,4.2]) linear_extrude(0.5)
                text(str(magnet_d+[0.15,0.30,0.45][i]),size=2.4,halign="center",valign="center");
        }
    }
}

// 用于容积和干涉检查的设计包络，均留在支架内；不能代替实物扫描。
module content_envelopes() {
    for(x=[-ear_x,ear_x]) translate([x,0,front_t+0.8])
        linear_extrude(20) rounded_rect(22,42,3);
    translate([0,0,front_t+0.8]) linear_extrude(8)
        rounded_rect(11,54,2);
}

module representative_earpods() {
    for(s=[-1,1]) translate([s*ear_x,0,front_t+1]) {
        color([0.97,0.97,0.95]) {
            translate([0,9,8.5]) scale([8.8,10.2,8.5]) sphere(r=1,$fn=48);
            translate([0,-6,5]) rotate([90,0,0]) cylinder(d=6.4,h=23,center=true,$fn=48);
        }
        color([0.15,0.16,0.16]) translate([s*6.6,9,12.5]) scale([1.3,4,2.6]) sphere(r=1,$fn=32);
    }
    color([0.98,0.98,0.96]) translate([0,0,front_t+0.8])
        linear_extrude(7) rounded_rect(10.5,51,3.5);
    // 尚未测得两条分支线长，因此不画会被误读为真实线长的绕线圈数。
}

module head_transform() {
    translate([0,tenon_depth/2,head_center_h]) rotate([90,0,0]) children();
}

module placed_lid(offset=0) {
    translate([0,0,body_depth+lid_t+offset]) rotate([180,0,0]) children();
}

module assembly(explode=0) {
    color(shell_color) stand();
    head_transform() {
        color(shell_color) body();
        if(explode>=0) placed_lid(explode) color(lid_color) lid();
        if(show_contents) representative_earpods();
        color([0.47,0.52,0.55]) {
            magnet_positions() translate([0,0,body_depth-magnet_h]) cylinder(d=magnet_d,h=magnet_h,$fn=64);
            if(explode>=0) placed_lid(explode) magnet_positions() translate([0,0,lid_t-magnet_h]) cylinder(d=magnet_d,h=magnet_h,$fn=64);
        }
    }
}

if(part=="body") body();
else if(part=="lid") lid();
else if(part=="stand") stand();
else if(part=="fit_coupon") fit_coupon();
else if(part=="assembly") assembly();
else if(part=="open") assembly(-1);
else if(part=="exploded") assembly(55);
else if(part=="envelopes") content_envelopes();
else if(part=="collision") intersection() {
    union() { body(); placed_lid() lid(); }
    content_envelopes();
}
else if(part=="layout") {
    translate([-65,62,0]) color(shell_color) body();
    translate([65,62,0]) color(lid_color) lid();
    translate([-65,-64,0]) color(shell_color) stand();
    translate([65,-64,0]) color(shell_color) fit_coupon();
}
