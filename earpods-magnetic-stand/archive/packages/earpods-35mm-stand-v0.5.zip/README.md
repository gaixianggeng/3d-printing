# EarPods 3.5 mm 磁吸支架（工程试装版 v0.5）

本版将主线藏入支杆，并从底座底面的开放槽引出。圆盘、插舌和支杆保持居中。数字几何检查通过，尚未实物试装或打印。

## 结构与尺寸

单位均为 mm。STL 按 100% 比例导入切片软件。

| 部位 | 设计尺寸 | 说明 |
| --- | --- | --- |
| 圆盘 | 直径 116，合盖厚 32.2 | 前板和侧壁均厚 2.4 |
| 整机 | 高 176，底座直径 108、厚 8 | 圆盘厚度中线与底座中心重合 |
| 支杆 | 外径 24，内孔直径 8 | 为中空接口保留壁厚，较 v0.4 加粗 4 |
| 插舌 | 12 × 14，插入长 8，中心孔直径 8 | 最薄侧壁 2；插舌底面距主体打印面 9.1 |
| 支杆插孔 | 12.4 × 14.4，深 8.4 | 角部到支杆外壁约 2.5 |
| 底座出线槽 | 宽 4，深 3.5 | 底面开放，从中心延伸到后侧边缘 |
| 通道转弯 | 中心线圆弧半径 6 | 连接支杆竖孔和底面槽 |
| 单耳参考外形 | 宽 14.5 × 长 35.6 × 厚 17.5 | 第三方尺寸图，非 Apple 制造图 |
| 单耳收纳槽 | 宽 19.5 × 长 39，内圆角 R3 | 入口倒角 0.6，槽壁约高 9 |
| 耳机区合盖净深 | 20 | 17.5 厚耳机加 0.8 软垫后仍余 1.7 |
| 线控槽 | 13 × 56 | 实际线控尺寸尚未获得可靠数据 |
| 线控检查包络 | 11 × 54 × 8 | 仅为设计检查值 |
| 线控正面窗口 | 8 × 48，托条宽 1.6，位于 Y = ±10 | 不得遮挡麦克风孔和按钮 |
| 线控限位筋处净深 | 10.7 | 8 厚检查包络加 0.8 垫片后余 1.9 |
| 磁铁 | 直径 5、厚 3，共 4 颗 | 顶部和底部各一对，用户已确认 |
| 磁铁盲孔 | 直径 5.30、深 3.15 | 后盖孔底剩 1.45 |
| 磁铁中心 | 圆心 Y = ±51.55 | 下磁铁孔与中央走线孔分开 |
| 后盖定位边间隙 | 径向每侧 0.30 | 需要打印试装 |

耳机采用“放入定位槽、合盖限位”的结构。开盖后可直接取出，不是弹性硬卡扣，也不保证完全无晃动。可在不遮挡声音孔的位置加可移除软垫；垫片不包含在 STL 中。

## 内部走线和装配

路线为：圆盘内的 Y 形分线器 → 圆盘中央通孔 → 中空插舌 → 中空支杆 → 底座下方 → 底面槽 → 电脑。

1. 先打印耳机卡位试件和磁铁试孔件，分别确认左右耳机和磁铁松紧。
2. 打印主体、后盖和支杆底座一体件。去除插舌下方支撑，清理通孔和槽内毛刺。
3. 打开后盖，从圆盘内将 3.5 mm 插头朝下穿过主体通孔和插舌。再让插头直穿支杆，从底座下面出来。
4. 将圆盘插舌插入支杆插孔，缓慢拉出多余主线。Y 形分线器留在圆盘内、通孔上方，避免把分线器拉进支杆。
5. 翻起底座，把已经穿出来的线横向放入底面槽。插头不用在支杆或底座内转弯，也不用穿过 4 mm 窄槽。确认线低于底面接触平面，再将底座放平。
6. 放入耳机和线控，在圆盘内按实际余量松绕两条分支线。线控的麦克风孔必须朝向窗口，避开托条，按钮不得被后盖或垫片压住。
7. 确认每对磁铁相吸后少量点胶固定，避免磁铁突出。合盖前检查线没有夹在接缝中，再验证电脑连接。

**按当前 Y 分线器示意位置，内部路线中心线长约 124.7 mm，即约 12.5 cm。** 这部分主线不能再算作底座之外的可用线长。内部留松量还会继续减少外露长度；实际值取决于分线器位置和实物线长。

8 mm 通道已用直径 7 mm 的连续直线包络检查穿线空间。这里的 7 mm 是设计检查值，不是已测得的插头外壳直径；“3.5 mm”仅说明接口规格。没有实测插头外壳尺寸，因此不能保证所有外壳或第三方同接口耳机都能穿过。完整主线、分支长度和线控尺寸也没有可靠公开制造数据，不承诺剩余外露厘米数。

## 打印文件与方向

- `earpods_stand.scad`：参数源文件，默认显示装配。将 `part` 设为 `section` 可查看内部走线剖视；剖视不能打印。
- `exports/body.stl`：主体，正面朝打印板。插舌及承重平肩下方需要局部支撑。检查横向通孔的切片桥接，确保打印后能清理通道。
- `exports/lid.stl`：后盖，外表面朝打印板，磁铁孔和限位台朝上。
- `exports/stand.stl`：支杆与底座一体件，底座底面朝打印板。检查底部 4 mm 槽的桥接；竖孔中不要留下无法清除的支撑。
- `exports/fit_coupon.stl`：磁铁试孔件，孔径 5.15、5.30、5.45，孔深均 3.15。
- `exports/ear_fit_coupon.stl`：单耳卡位试件，约 28.7 × 48.2 × 11.38。仅验证平面卡位和放入过程，不验证整机合盖深度。
- `preview/section.png`：内部通道剖视，橙色为主线示意。
- `preview/front.png`、`inside.png`、`side.png`、`lid_inside.png`：外观、开盖、侧视和后盖内侧。
- `preview/envelopes.stl`、`head_alignment.stl`、`cable_check.stl`：几何检查模型，不能作为打印零件。
- `verify_model.py`、`preview/geometry-check.json`：检查脚本与结果。

试打起点：0.4 mm 喷嘴、0.2 mm 层高、4 道壁，主体和后盖 20% 填充，底座 35% 填充。尚未切片或实际打印，必须结合切片预览确认支撑和桥接。不要混用 v0.4 的旧主体、旧支杆与 v0.5 接口。

## 实际验证与资料边界

OpenSCAD 2026.04.26 在 `--hardwarnings` 下导出。5 个打印零件均为封闭网格和单一连通实体。Python 3.11、trimesh 与 Manifold 的 35 项干涉及路径检查通过；另检查了实际圆盘装配中线和插舌中心。

本次检查包括：耳机两种正交朝向和背面直线放入路径；后盖限位；壳盖及支杆装配；4 个磁铁孔；直径 2.5 mm 的完整内部走线包络；直径 7 mm 插头的竖直穿入路径；5.2 × 8 mm 的 Y 分线器示意包络。线控、插头、分线器和线径都是注明的设计检查值，不能代替实物尺寸。打印收缩、插舌强度、磁吸力度、线缆弯曲适配、完整绕线和拾音效果尚未验证。

资料：

- [Apple：EarPods（3.5 mm 插头）](https://www.apple.com/shop/product/mwu53am/a/earpods-35mm-headphone-plug)：确认版本及功能，未提供完整机械尺寸。
- [Dimensions.com：EarPods 尺寸图](https://www.dimensions.com/element/apple-earpods-2012)：单耳参考尺寸 35.6 × 14.5 × 17.5；没有制造公差。
- [我爱音频网：3.5 mm EarPods 拆解](https://www.52audio.com/archives/20540.html)：样本总长度约 118 cm，没有分段线长，不能将总长当作底座外可用长度。

重新导出并检查（Python 环境需已有 numpy、trimesh、manifold3d）：

```sh
cd /Users/gaixiaotongxue/code/earpods-magnetic-stand
openscad --hardwarnings --export-format binstl -D 'part="body"' -o exports/body.stl earpods_stand.scad
openscad --hardwarnings --export-format binstl -D 'part="lid"' -o exports/lid.stl earpods_stand.scad
openscad --hardwarnings --export-format binstl -D 'part="stand"' -o exports/stand.stl earpods_stand.scad
openscad --hardwarnings --export-format binstl -D 'part="fit_coupon"' -o exports/fit_coupon.stl earpods_stand.scad
openscad --hardwarnings --export-format binstl -D 'part="ear_fit_coupon"' -o exports/ear_fit_coupon.stl earpods_stand.scad
openscad --hardwarnings --export-format binstl -D 'part="envelopes"' -o preview/envelopes.stl earpods_stand.scad
openscad --hardwarnings --export-format binstl -D 'part="preview_only"' -o preview/head_alignment.stl preview/head_alignment.scad
openscad --hardwarnings --export-format binstl -D 'part="preview_only"' -o preview/cable_check.stl preview/cable_check.scad
python3.11 verify_model.py
```

报告记录了源文件及 5 个打印 STL 的校验值。修改参数后须重新导出并运行检查。
